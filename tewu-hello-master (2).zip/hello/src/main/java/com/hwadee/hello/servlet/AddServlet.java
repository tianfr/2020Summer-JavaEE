package com.hwadee.hello.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hwadee.hello.dao.StudentDao2;
import com.hwadee.hello.entity.Student;

public class AddServlet extends HttpServlet {
	
	private StudentDao2 dao = new StudentDao2();

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		String stuName = req.getParameter("stuName");
		String stuSex = req.getParameter("stuSex");
		String stuAge = req.getParameter("stuAge");
		String stuPro = req.getParameter("stuPro");
		Student student = new Student(
					stuName,
					stuSex,
					Integer.parseInt(stuAge),
					stuPro
				);
		
		resp.setContentType("text/html;charset=UTF-8");
		PrintWriter out = resp.getWriter();
		out.println("<!DOCTYPE html>");
		out.println("<html lang=\"en\">");
		out.println("<head>");
		out.println("	<meta charset=\"UTF-8\">");
		out.println("	<title>学生列表</title>");
		out.println("</head>");
		out.println("<body>");
	
			long id = dao.insert(student);
			out.println("<h1>");
			out.print("添加成功id是:");
			out.print(id);
			out.println("</h1>");
			out.println("<a href='/students'>回到学生列表</a>");
		
		out.println("</body>");
		out.println("</html>");
		out.close();
	}

}
