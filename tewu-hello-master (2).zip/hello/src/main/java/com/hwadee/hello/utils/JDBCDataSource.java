package com.hwadee.hello.utils;

import javax.sql.DataSource;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class JDBCDataSource {
	
	private static DataSource dataSource;
	
	static {
		HikariConfig config = new HikariConfig();
		config.setMaximumPoolSize(100);
		config.setJdbcUrl("jdbc:mysql://127.0.0.1:3306/test");
		config.setDriverClassName("com.mysql.jdbc.Driver");
		config.setUsername("root");
		config.setPassword("123456");

		dataSource = new HikariDataSource(config);
	}
	
	public static DataSource getDataSource() {
		return dataSource;
	}

}
